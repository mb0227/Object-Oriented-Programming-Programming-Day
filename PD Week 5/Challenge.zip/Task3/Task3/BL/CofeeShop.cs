﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    internal class CoffeeShop
    {
        public CoffeeShop() { }
        public CoffeeShop(string name) 
        {
            ShopName = name;
        } 
        public string ShopName;
    }
}
